package dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.CategoriaVehiculo;
import modelo.Marca;
import modelo.ModeloVehiculo;
import modelo.Sucursal;
import modelo.Vehiculo;

public class VehiculoDaoImpl implements IVehiculoDao {

    @Override
    public boolean insertar(Vehiculo vehiculo) {
        String sqlQuery = String.format(
            "INSERT INTO vehiculos (patente, id_modelo, id_categoria, estado, id_sucursal_actual, kilometraje_actual, vencimiento_seguro, vencimiento_patente) " +
            "VALUES ('%s', %d, %d, '%s', %d, %d, '%s', '%s')",
            vehiculo.getPatente(), vehiculo.getModelo().getIdModelo(), vehiculo.getCategoria().getIdCategoria(),
            vehiculo.getEstado(), vehiculo.getSucursalActual().getIdSucursal(), vehiculo.getKilometrajeActual(),
            vehiculo.getVencimientoSeguro().toString(), vehiculo.getVencimientoPatente().toString()
        );

        try (Connection con = ConexionBD.obtenerConexion();
             CallableStatement cs = con.prepareCall("{CALL sp_general_insertar(?)}")) {
            cs.setString(1, sqlQuery);
            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean actualizar(Vehiculo vehiculo) {
        String sqlQuery = String.format(
            "UPDATE vehiculos SET patente='%s', id_modelo=%d, id_categoria=%d, estado='%s', id_sucursal_actual=%d, kilometraje_actual=%d, vencimiento_seguro='%s', vencimiento_patente='%s' WHERE id_vehiculo=%d",
            vehiculo.getPatente(), vehiculo.getModelo().getIdModelo(), vehiculo.getCategoria().getIdCategoria(),
            vehiculo.getEstado(), vehiculo.getSucursalActual().getIdSucursal(), vehiculo.getKilometrajeActual(),
            vehiculo.getVencimientoSeguro().toString(), vehiculo.getVencimientoPatente().toString(), vehiculo.getIdVehiculo()
        );

        try (Connection con = ConexionBD.obtenerConexion();
             CallableStatement cs = con.prepareCall("{CALL sp_general_actualizar(?)}")) {
            cs.setString(1, sqlQuery);
            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean eliminar(int idVehiculo) {
        String sqlQuery = "DELETE FROM vehiculos WHERE id_vehiculo = " + idVehiculo;
        try (Connection con = ConexionBD.obtenerConexion();
             CallableStatement cs = con.prepareCall("{CALL sp_general_eliminar(?)}")) {
            cs.setString(1, sqlQuery);
            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Vehiculo obtenerPorId(int idVehiculo) {
        String sqlQuery = "SELECT v.*, mv.id_marca, c.nombre_categoria FROM vehiculos v " +
                           "INNER JOIN modelos_vehiculo mv ON v.id_modelo = mv.id_modelo " +
                           "INNER JOIN categorias c ON v.id_categoria = c.id_categoria WHERE v.id_vehiculo = " + idVehiculo;
        try (Connection con = ConexionBD.obtenerConexion();
             CallableStatement cs = con.prepareCall("{CALL sp_general_obtener_por_id(?)}")) {
            cs.setString(1, sqlQuery);
            try (ResultSet rs = cs.executeQuery()) {
                if (rs.next()) {
                    return mapearVehiculo(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Vehiculo> obtenerTodos() {
        List<Vehiculo> lista = new ArrayList<>();
        String sqlQuery = "SELECT v.*, mv.id_marca, c.nombre_categoria FROM vehiculos v " +
                           "INNER JOIN modelos_vehiculo mv ON v.id_modelo = mv.id_modelo " +
                           "INNER JOIN categorias c ON v.id_categoria = c.id_categoria";
        try (Connection con = ConexionBD.obtenerConexion();
             CallableStatement cs = con.prepareCall("{CALL sp_general_obtener_todos(?)}")) {
            cs.setString(1, sqlQuery);
            try (ResultSet rs = cs.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearVehiculo(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    private Vehiculo mapearVehiculo(ResultSet rs) throws SQLException {
        Marca marca = new Marca();
        marca.setIdMarca(rs.getInt("id_marca"));
        
        ModeloVehiculo modelo = new ModeloVehiculo();
        modelo.setIdModelo(rs.getInt("id_modelo"));
        modelo.setMarca(marca);
        
        CategoriaVehiculo cat = new CategoriaVehiculo();
        cat.setIdCategoria(rs.getInt("id_categoria"));
        cat.setNombreCategoria(rs.getString("nombre_categoria"));
        
        Sucursal suc = new Sucursal();
        suc.setIdSucursal(rs.getInt("id_sucursal_actual"));
        
        Vehiculo vehiculo = new Vehiculo();
        vehiculo.setIdVehiculo(rs.getInt("id_vehiculo"));
        vehiculo.setPatente(rs.getString("patente"));
        vehiculo.setModelo(modelo);
        vehiculo.setCategoria(cat);
        vehiculo.setSucursalActual(suc);
        vehiculo.setKilometrajeActual(rs.getInt("kilometraje_actual"));
        vehiculo.setEstado(rs.getString("estado"));
        
        java.sql.Date seg = rs.getDate("vencimiento_seguro");
        if (seg != null) {
            vehiculo.setVencimientoSeguro(seg.toLocalDate());
        }
        
        java.sql.Date pat = rs.getDate("vencimiento_patente");
        if (pat != null) {
            vehiculo.setVencimientoPatente(pat.toLocalDate());
        }
        return vehiculo;
    }
}
