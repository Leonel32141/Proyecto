package dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import modelo.Alquiler;
import modelo.Cliente;
import modelo.Sucursal;
import modelo.Vehiculo;

public class AlquilerDaoImpl implements IAlquilerDao {

    @Override
    public boolean insertar(Alquiler alquiler) {
        String sqlQuery = String.format(
            "INSERT INTO alquileres (id_cliente, id_vehiculo, id_sucursal_retiro, id_sucursal_devolucion, fecha_reserva, fecha_inicio_pautada, fecha_fin_pautada, es_oneway, monto_total, monto_sena, estado_reserva) " +
            "VALUES (%d, %d, %d, %d, '%s', '%s', '%s', %b, %f, %f, '%s')",
            alquiler.getCliente().getIdUsuario(), alquiler.getVehiculo().getIdVehiculo(), alquiler.getSucursalRetiro().getIdSucursal(), alquiler.getSucursalDevolucion().getIdSucursal(),
            Timestamp.valueOf(alquiler.getFechaReserva()).toString(), Timestamp.valueOf(alquiler.getFechaInicioPautada()).toString(), Timestamp.valueOf(alquiler.getFechaFinPautada()).toString(),
            alquiler.isEsOneway(), alquiler.getMontoTotal(), alquiler.getMontoSena(), alquiler.getEstadoReserva()
        );

        try (Connection con = ConexionBD.obtenerConexion();
             CallableStatement cs = con.prepareCall("{CALL sp_general_insertar(?)}")) {
            cs.setString(1, sqlQuery);
            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean actualizar(Alquiler alquiler) {
        String sqlQuery = String.format(
            "UPDATE alquileres SET id_cliente=%d, id_vehiculo=%d, id_sucursal_retiro=%d, id_sucursal_devolucion=%d, fecha_reserva='%s', fecha_inicio_pautada='%s', fecha_fin_pautada='%s', es_oneway=%b, monto_total=%f, monto_sena=%f, estado_reserva='%s' WHERE id_alquiler=%d",
            alquiler.getCliente().getIdUsuario(), alquiler.getVehiculo().getIdVehiculo(), alquiler.getSucursalRetiro().getIdSucursal(), alquiler.getSucursalDevolucion().getIdSucursal(),
            Timestamp.valueOf(alquiler.getFechaReserva()).toString(), Timestamp.valueOf(alquiler.getFechaInicioPautada()).toString(), Timestamp.valueOf(alquiler.getFechaFinPautada()).toString(),
            alquiler.isEsOneway(), alquiler.getMontoTotal(), alquiler.getMontoSena(), alquiler.getEstadoReserva(), alquiler.getIdAlquiler()
        );

        try (Connection con = ConexionBD.obtenerConexion();
             CallableStatement cs = con.prepareCall("{CALL sp_general_actualizar(?)}")) {
            cs.setString(1, sqlQuery);
            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean eliminar(int idAlquiler) {
        String sqlQuery = "DELETE FROM alquileres WHERE id_alquiler = " + idAlquiler;
        try (Connection con = ConexionBD.obtenerConexion();
             CallableStatement cs = con.prepareCall("{CALL sp_general_eliminar(?)}")) {
            cs.setString(1, sqlQuery);
            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Alquiler obtenerPorId(int idAlquiler) {
        String sqlQuery = "SELECT * FROM alquileres WHERE id_alquiler = " + idAlquiler;
        try (Connection con = ConexionBD.obtenerConexion();
             CallableStatement cs = con.prepareCall("{CALL sp_general_obtener_por_id(?)}")) {
            cs.setString(1, sqlQuery);
            try (ResultSet rs = cs.executeQuery()) {
                if (rs.next()) {
                    return mapearAlquiler(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Alquiler> obtenerTodos() {
        List<Alquiler> lista = new ArrayList<>();
        String sqlQuery = "SELECT * FROM alquileres";
        try (Connection con = ConexionBD.obtenerConexion();
             CallableStatement cs = con.prepareCall("{CALL sp_general_obtener_todos(?)}")) {
            cs.setString(1, sqlQuery);
            try (ResultSet rs = cs.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearAlquiler(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    private Alquiler mapearAlquiler(ResultSet rs) throws SQLException {
        Cliente cli = new Cliente();
        cli.setIdUsuario(rs.getInt("id_cliente"));
        
        Vehiculo veh = new Vehiculo();
        veh.setIdVehiculo(rs.getInt("id_vehiculo"));
        
        Sucursal ret = new Sucursal();
        ret.setIdSucursal(rs.getInt("id_sucursal_retiro"));
        
        Sucursal dev = new Sucursal();
        dev.setIdSucursal(rs.getInt("id_sucursal_devolucion"));
        
        Alquiler alquiler = new Alquiler();
        alquiler.setIdAlquiler(rs.getInt("id_alquiler"));
        alquiler.setCliente(cli);
        alquiler.setVehiculo(veh);
        alquiler.setSucursalRetiro(ret);
        alquiler.setSucursalDevolucion(dev);
        
        Timestamp tRes = rs.getTimestamp("fecha_reserva");
        if (tRes != null) alquiler.setFechaReserva(tRes.toLocalDateTime());
        
        Timestamp tIni = rs.getTimestamp("fecha_inicio_pautada");
        if (tIni != null) alquiler.setFechaInicioPautada(tIni.toLocalDateTime());
        
        Timestamp tFin = rs.getTimestamp("fecha_fin_pautada");
        if (tFin != null) alquiler.setFechaFinPautada(tFin.toLocalDateTime());
        
        alquiler.setEsOneway(rs.getBoolean("es_oneway"));
        alquiler.setMontoTotal(rs.getDouble("monto_total"));
        alquiler.setMontoSena(rs.getDouble("monto_sena"));
        alquiler.setEstadoReserva(rs.getString("estado_reserva"));
        
        return alquiler;
    }
}
