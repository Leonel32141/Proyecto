package dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import modelo.Rol;
import modelo.Usuario;

public class UsuarioDaoImpl implements IUsuarioDao {

    @Override
    public boolean insertar(Usuario usuario) {
        String sqlQuery = String.format(
            "INSERT INTO usuarios (id_rol, email, password_hash, nombre, apellido, cuil, telefono, intentos_fallidos, cuenta_bloqueada, fecha_creacion) " +
            "VALUES (%d, '%s', '%s', '%s', '%s', '%s', '%s', 0, %b, NOW())",
            usuario.getRol().getIdRol(), usuario.getEmail(), usuario.getPasswordHash(),
            usuario.getNombre(), usuario.getApellido(), usuario.getCuil(), usuario.getTelefono(), usuario.isCuentaBloqueada()
        );

        try (Connection con = ConexionBD.obtenerConexion();
             CallableStatement cs = con.prepareCall("{CALL sp_general_insertar(?)}")) {
            cs.setString(1, sqlQuery);
            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean actualizar(Usuario usuario) {
        String sqlQuery = String.format(
            "UPDATE usuarios SET id_rol=%d, email='%s', password_hash='%s', nombre='%s', apellido='%s', cuil='%s', telefono='%s', intentos_fallidos=%d, cuenta_bloqueada=%b WHERE id_usuario=%d",
            usuario.getRol().getIdRol(), usuario.getEmail(), usuario.getPasswordHash(),
            usuario.getNombre(), usuario.getApellido(), usuario.getCuil(), usuario.getTelefono(),
            usuario.getIntentosFallidos(), usuario.isCuentaBloqueada(), usuario.getIdUsuario()
        );

        try (Connection con = ConexionBD.obtenerConexion();
             CallableStatement cs = con.prepareCall("{CALL sp_general_actualizar(?)}")) {
            cs.setString(1, sqlQuery);
            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean eliminar(int idUsuario) {
        String sqlQuery = "DELETE FROM usuarios WHERE id_usuario = " + idUsuario;
        try (Connection con = ConexionBD.obtenerConexion();
             CallableStatement cs = con.prepareCall("{CALL sp_general_eliminar(?)}")) {
            cs.setString(1, sqlQuery);
            return cs.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Usuario obtenerPorId(int idUsuario) {
        String sqlQuery = "SELECT u.*, r.nombre_rol, r.desc_rol FROM usuarios u INNER JOIN roles r ON u.id_rol = r.id_rol WHERE u.id_usuario = " + idUsuario;
        try (Connection con = ConexionBD.obtenerConexion();
             CallableStatement cs = con.prepareCall("{CALL sp_general_obtener_por_id(?)}")) {
            cs.setString(1, sqlQuery);
            try (ResultSet rs = cs.executeQuery()) {
                if (rs.next()) {
                    return mapearUsuario(rs);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Usuario> obtenerTodos() {
        List<Usuario> lista = new ArrayList<>();
        String sqlQuery = "SELECT u.*, r.nombre_rol, r.desc_rol FROM usuarios u INNER JOIN roles r ON u.id_rol = r.id_rol";
        try (Connection con = ConexionBD.obtenerConexion();
             CallableStatement cs = con.prepareCall("{CALL sp_general_obtener_todos(?)}")) {
            cs.setString(1, sqlQuery);
            try (ResultSet rs = cs.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapearUsuario(rs));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }

    private Usuario mapearUsuario(ResultSet rs) throws SQLException {
        Rol rol = new Rol();
        rol.setIdRol(rs.getInt("id_rol"));
        rol.setNombreRol(rs.getString("nombre_rol"));
        rol.setDescripcion(rs.getString("desc_rol"));
        
        Usuario usuario = new Usuario();
        usuario.setIdUsuario(rs.getInt("id_usuario"));
        usuario.setRol(rol);
        usuario.setEmail(rs.getString("email"));
        usuario.setPasswordHash(rs.getString("password_hash"));
        usuario.setNombre(rs.getString("nombre"));
        usuario.setApellido(rs.getString("apellido"));
        usuario.setCuil(rs.getString("cuil"));
        usuario.setTelefono(rs.getString("telefono"));
        usuario.setIntentosFallidos(rs.getInt("intentos_fallidos"));
        usuario.setCuentaBloqueada(rs.getBoolean("cuenta_bloqueada"));
        
        Timestamp ts = rs.getTimestamp("fecha_creacion");
        if (ts != null) {
            usuario.setFechaCreacion(ts.toLocalDateTime());
        }
        return usuario;
    }
}
